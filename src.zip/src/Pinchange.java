import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pinchange extends JPanel implements ActionListener {
    JButton submitButton;
    JTextField pinchangeTextField,pinchangeTextField1;
    Pinchange() {
        setBounds(50, 550, 400, 400);
        setBackground(Color.CYAN);

        JLabel label = new JLabel("ENTER YOUR PREVIOUS PIN");
        label.setFont(new Font("System", Font.BOLD, 16));
        label.setForeground(Color.black);
        label.setBounds(10, 10, 400, 20);
        add(label);

        pinchangeTextField = new JTextField();
        pinchangeTextField.setBackground(new Color(65, 125, 128));
        pinchangeTextField.setBounds(10, 40, 320, 25);
        pinchangeTextField.setFont(new Font("Arial", Font.BOLD, 22));
        pinchangeTextField.setBackground(Color.white);
        add(pinchangeTextField);

        JLabel label2 = new JLabel("ENTER YOUR NEW PIN"); // Changed label text
        label2.setFont(new Font("System", Font.BOLD, 16));
        label2.setForeground(Color.black);
        label2.setBounds(10, 70, 400, 20);
        add(label2);

        pinchangeTextField1 = new JTextField(); // Changed variable name
        pinchangeTextField1.setBackground(new Color(65, 125, 128)); // Changed variable name
        pinchangeTextField1.setBounds(10, 100, 320, 25); // Changed variable name
        pinchangeTextField1.setFont(new Font("Arial", Font.BOLD, 22)); // Changed variable name
        pinchangeTextField1.setBackground(Color.white); // Changed variable name
        add(pinchangeTextField1); // Changed variable name

        submitButton = new JButton("SUBMIT");
        submitButton.setBounds(10, 140, 150, 35);
        submitButton.setBackground(Color.white);
        submitButton.addActionListener(this);
        add(submitButton);

        setLayout(null);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
//            String withdrawAmount = withdrawTextField.getText();
            pinchangeTextField.setText(null);
            pinchangeTextField1.setText(null);
            JOptionPane.showMessageDialog(null, "PIN changed successfully");
        }
    }
}
