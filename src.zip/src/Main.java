

public class Main {
    public static void main(String[] args) throws InterruptedException {
        new Register_page();
//        new Login_page1();
//        MainFrame mainFrame = new MainFrame();
    }
}