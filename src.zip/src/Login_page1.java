import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login_page1 extends JFrame
{
    JLabel usernameLabel,passwordLabel;
    JTextField usernameTextField,passwordField;
    static final int frameWidth = 1400;
    static final int frameHeight = 800;
    Login_page1()
    {
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("login image.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1400, 800, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 1400, 800);
        add(l3);


        setTitle("LOGIN PAGE ");
        setSize(1400,800);
        getContentPane().setBackground(new Color(150, 239, 255));


        usernameLabel=new JLabel("USER NAME :");
        usernameLabel.setForeground(Color.white);
        usernameLabel.setFont(new Font("System", Font.BOLD,26));
        usernameLabel.setBounds(650,300,200,50);
        l3.add(usernameLabel);


        usernameTextField = new JTextField();
        usernameTextField.setBounds(850,300,250,50);
        usernameTextField.setBackground(new Color(197, 255, 248));
        usernameTextField.setFont(new Font("System", Font.BOLD,20));
        l3.add(usernameTextField);

        passwordLabel=new JLabel("PASSWORD :");
        passwordLabel.setForeground(Color.white);
        passwordLabel.setFont(new Font("System", Font.BOLD,26));
        passwordLabel.setBounds(650,400,200,50);
        l3.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(850,400,250,50);
        passwordField.setBackground(new Color(197, 255, 248));
        passwordField.setFont(new Font("System", Font.BOLD,22));
        l3.add(passwordField);

        JButton submitButton =new JButton("SUBMIT");
        submitButton.setBounds(780,500,170,45);
        submitButton.setBackground(new Color(197, 255, 248));
        submitButton.setFont(new Font("System", Font.BOLD,24));
        l3.add(submitButton);

        JButton registerButton =new JButton("REGISTER");
        registerButton.setBounds(1000,500,170,45);
        registerButton.setBackground(new Color(197, 255, 248));
        registerButton.setFont(new Font("System", Font.BOLD,24));
        l3.add(registerButton);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Register_page();
            }
        });

        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public static void main(String[] args) throws InterruptedException {
        new Login_page1();
//        new Register_page();

//            MainFrame mainFrame = new MainFrame();
    }
        }