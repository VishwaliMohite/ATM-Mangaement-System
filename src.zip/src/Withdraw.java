import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Withdraw extends JPanel implements ActionListener {
    JTextField withdrawTextField;
    JButton withdrawButton;

    Withdraw() throws InterruptedException {
        setBounds(50, 550, 400, 400);
        setBackground(Color.CYAN);


        JLabel label = new JLabel("ENTER AMOUNT YOU WANT TO WITHDRAW");
        label.setFont(new Font("System", Font.BOLD, 16));
        label.setForeground(Color.black);
        label.setBounds(10, 10, 400, 20);
        add(label);

        withdrawTextField= new JTextField();
        withdrawTextField.setBackground(new Color(65, 125, 128));
        withdrawTextField.setBounds(10, 40, 320, 25);
        withdrawTextField.setFont(new Font("Arial", Font.BOLD, 22));
        withdrawTextField.setBackground(Color.white);
        add(withdrawTextField);

        withdrawButton = new JButton("WITHDRAW");
        withdrawButton.setBounds(10, 80, 150, 35);
        withdrawButton.setBackground(Color.white);
        withdrawButton.addActionListener(this);
        add(withdrawButton);

        setLayout(null);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == withdrawButton) {
            String withdrawAmount = withdrawTextField.getText();
            withdrawTextField.setText(null);
            JOptionPane.showMessageDialog(null, withdrawAmount + "has withdrawn successfully");
        }
    }
}
