import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Deposit extends JPanel implements ActionListener {
    JButton depositButton;
    JTextField depositTextField;

    Deposit() throws InterruptedException {
        setBounds(50, 550, 400, 400);
        setBackground(Color.CYAN);

        JLabel depositLabel = new JLabel("ENTER AMOUNT YOU WANT TO DEPOSIT");
        depositLabel.setFont(new Font("System", Font.BOLD, 16));
        depositLabel.setForeground(Color.black);
        depositLabel.setBounds(10, 10, 400, 20);
        add(depositLabel);

        depositTextField = new JTextField();
        depositTextField.setBackground(new Color(65, 125, 128));
        depositTextField.setBounds(10, 40, 320, 25);
        depositTextField.setFont(new Font("Arial", Font.BOLD, 22));
        depositTextField.setBackground(Color.white);
        add(depositTextField);

        depositButton = new JButton("DEPOSIT");
        depositButton.setBounds(10, 80, 150, 35);
        depositButton.setBackground(Color.white);
        depositButton.addActionListener(this); // Add ActionListener to the button
        add(depositButton);

        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == depositButton) {
            String depositAmount = depositTextField.getText();
            depositTextField.setText(null);
            JOptionPane.showMessageDialog(null, depositAmount + " is deposited successfully");
        }
    }
}
//    public static void main(String[] args) throws InterruptedException {
//        JFrame frame = new JFrame("Deposit Example");
//        frame.setSize(500, 500);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//        Deposit depositPanel = new Deposit();
//        frame.add(depositPanel);
//
//        frame.setLayout(null);
//        frame.setVisible(true);
//    }
//}
