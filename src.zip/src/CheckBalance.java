import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckBalance extends JPanel implements ActionListener {
    JButton submitButton;
    JTextField pinTextField;

    CheckBalance() throws InterruptedException {
        setBounds(50, 550, 400, 400);
        setBackground(Color.CYAN);

        JLabel label = new JLabel("ENTER PIN");
        label.setFont(new Font("System", Font.BOLD, 16));
        label.setForeground(Color.BLACK);
        label.setBounds(10, 10, 400, 20);
        add(label);

        pinTextField= new JTextField();
        pinTextField.setBackground(new Color(65, 125, 128));
        pinTextField.setBounds(10, 40, 320, 25);
        pinTextField.setFont(new Font("Arial", Font.BOLD, 22));
        pinTextField.setBackground(Color.white);
        add(pinTextField);

        submitButton = new JButton("SUBMIT");
        submitButton.setBounds(10, 80, 150, 25);
        submitButton.setBackground(Color.white);
        submitButton.addActionListener(this);
        add(submitButton);

        JLabel label2 = new JLabel("AVAILABLE BALANCE IS:");
        label2.setFont(new Font("System", Font.BOLD, 16));
        label2.setForeground(Color.BLACK);
        label2.setBounds(10, 120, 400, 20);
        add(label2);

        JTextField textField2 = new JTextField();
        textField2.setBackground(new Color(65, 125, 128));
        textField2.setBounds(10, 160, 320, 25);
        textField2.setFont(new Font("Arial", Font.BOLD, 22));
        textField2.setBackground(Color.white);
        add(textField2);
        setLayout(null);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
//            String withdrawAmount =pinTextField.getText();
            pinTextField.setText(null);
            JOptionPane.showMessageDialog(null, "Available balance is ");
        }
    }
}
